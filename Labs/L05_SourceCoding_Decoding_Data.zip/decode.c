#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)   ((x) & (1U<<(i)))
#define CLEAR_BIT(x,i)  ((x)=(x) & ~(1U<<(i)))
#define SET_BIT(x,i)    ((x)=(x) | (1U<<(i)))
#define TOGGLE_BIT(x,i) ((x)=(x) ^ (1U<<(i)))


/* Structure definition for describing a codeword */
typedef struct{
	int len;
	unsigned long code;
}CODE32BIT;

/* Main function
 * Our program needs three arguments: the code file, the encoded file, the output decoded file
 *  */
int main(int argc, char *argv[]) {
	
	/*----- TODO: Declare small variables here ------*/
	...
	/*-----------------------------------------*/

	FILE *f;
		
	/* Declare a vector of CODE32BIT structures, holding the codeword of each possible byte
	 * The vector data will be read from the code file */
	CODE32BIT codebook[256];
	
	/* A vector of bytes, to hold all the data from the encoded file 
	 * We read all the encoded file into this vector,
	 * because it's easier to work with vectors rather than the disk file */
	unsigned char mem[100000];



	
	/* Open the code file (first argument) and read everything into the `codebook` vector.
	 * File can be closed afterwards */

	/*----- TODO: Open code file ------*/
	f = ... ;
	/*---------------------------------*/
	if(!f)
	{
		printf("Eroare la deschiderea fisierului 1");
		exit(1);
	}
	/*----- TODO: Read all the vector `codebook` from the file ------*/
	fread(...);
	/*---------------------------------*/
	
	fclose(f);



	/* Open the encoded file (second argument) and read everything into the mem vector.
	 * File can be closed afterwards */
	 
	/*----- TODO: Open encoded file ------*/
	f = ...;
	/*------------------------------------*/
	
    /*----- TODO: Check if file is open, 
	 * display message and exit if it is not ------*/
	if(...)
	{
		...
	}	
	
	/*----- TODO: Read as much as possible data into the `mem` vector ------*/
	/*------------nb will store the number of bytes read -------------------*/
	nb = ...
	/*------------------------------------*/
	
	fclose(f);




	/* Open the output file (third argument). We will write the outputs in this file.*/
	/*----- TODO: Open output file ------*/
	f = ...
	/*------------------------------------*/
	
	
	/* Go through the `mem` vector, starting from the beginning 
	 * Do not exceed the total number of bytes actual read from the file*/
	while(n<nb*8)
	{
		/* Find which codeword matches the next bits in the `mem` vector */
		
		/* Go through all the 256 codewords */
		for(i=0;i<256;i++)
		{
			/* Go through all the bits in the codeword
			 * Check if first bit in codeword matches the next bit in `mem`
			 * If yes, then check the second bit, and so on. 
			 * - If the codeword finishes, and all bits are matched => this is the decoded byte
			 *     Write the byte in the output file
			 * - If a bit is different, then break and start checking the next codeword */
			 
			found=1;
			for(j=0; ... ; ... )
			{
                /* Check if next bit from 'mem' is different from next bit in codeword */
				if( ... )
				{
					found = ...
					break;  /* when do we break? when it is good or bad ?*/
				}
				
			}
			/* found == 1 means that all bits have matched
			 * found == 0 means that a bit was different */
			if(found)
			{
				// Write variable `i` (1 byte) in the output file 
				fwrite(&i,1,1,f);	
                
                // Advance in the `mem` vector with the length of the codeword
				n = n + ...
                
                // Done checking, restart checking all codewords from the new position
				break;
			}
		}
	}
	
    // Close file 
	fclose(f);
	
	
	return 0;
}
