#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)       (((x) & (1U << (i))) != 0)
#define SET_BIT(x,i)        ((x) = (x) | (1U << (i)))
#define CLEAR_BIT(x,i)      ((x) = (x) & ~(1U << (i)))
#define TOGGLE_BIT(x,i)     ((x) = (x) ^ (1U << (i)))
#define WRITE_BIT(x,i,val)  ((val) ? SET_BIT((x),(i)) : CLEAR_BIT((x),(i)))

#define VECREAD_BIT(v,i)      (READ_BIT((v[(i)/8]),(i)%8))
#define VECWRITE_BIT(v,i,val) (WRITE_BIT((v[(i)/8]),(i)%8, val))


/* Fire away!
 * Our program needs two arguments: the input file, the output file
 *  */
int main(int argc, char *argv[]) {
	
	/* Small int variables here */
    int i, j, inpos, outpos, parity, numberbytes, sum;
	

    /* Declare two large vectors of `unsigned char`, for input and output bits	*/
    unsigned char in[100000], out[100000];
    
    /* For working with files */
	FILE *f;
    
    /* Open the input file (first argument) and read everything into the `in` vector.
	 * File can be closed afterwards */
	f = fopen(argv[1], "rb");
	if(f == NULL)
	{
		printf("eroare la deschidere f1");
		exit(1);
	}
    
    /* Read as much as possible into the `in` vector */
    /* Record the number of bytes actually read */
    numberbytes = fread(in, 1, 100000, f);
    
    /* Now we can close the input file */
    fclose(f);
    
    /* Go through all the `in` vector */     
    inpos = 0;   /* the current bit position in the `in` vector */
    outpos = 0;  /* the current bit position in the `out` vector */
    while (inpos < 8*numberbytes)
    {
        /* Copy the next 8 `in` bits in the `out` vector */
        /* See definitions of VECWRITE_BIT and VECREAD_BIT*/
        for (i = 0; i < 8; i++)
            VECWRITE_BIT(out , outpos+i , VECREAD_BIT(in, inpos+i));
        
        /* Compute the parity bit of the 8 bits copied*/
        parity = 0;
        for (i = 0; i < 8; i++)
        {
            parity = parity + VECREAD_BIT(in, inpos+i);
        }
        parity = parity % 2;
        
        /* Check the parity bit */
        if (parity != VECREAD_BIT(in, inpos+8))
            printf("Error detected at byte number %d\n", inpos/8);
        
        /* Advance inpos and outpos by necessary amount*/
        inpos  = inpos  + 9;
        outpos = outpos + 8;
    }
    
	/* Open the output file and save all the `out` vector */
    /* How many bytes should we write? */
	f = fopen(argv[2], "wb");
	fwrite(out, 1, ceil(outpos / 8.0), f);
	fclose(f);

	return 0;
}
