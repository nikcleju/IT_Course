#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)       (((x) & (1U << (i))) != 0)
#define SET_BIT(x,i)        ((x) = (x) | (1U << (i)))
#define CLEAR_BIT(x,i)      ((x) = (x) & ~(1U << (i)))
#define TOGGLE_BIT(x,i)     ((x) = (x) ^ (1U << (i)))
#define WRITE_BIT(x,i,val)  ((val) ? SET_BIT((x),(i)) : CLEAR_BIT((x),(i)))

#define VECREAD_BIT(v,i)      (READ_BIT((v[(i)/8]),(i)%8))
#define VECWRITE_BIT(v,i,val) (WRITE_BIT((v[(i)/8]),(i)%8, val))


/* Fire away!
 * Our program needs three arguments: the probability of error, the input file, the output file
 *  */
int main(int argc, char *argv[]) {
	
	int i,x,b;
	double p;
	
    /* Declare a large vector of `unsigned char`	*/
    unsigned char in[100000];    
    
    /* Declare the file variable*/
	FILE *f;

	// Read the floating-point number given as first argument to the program
	sscanf(argv[1],"%f",&p);

	// Open the input file
	f = ...
	if(...)
	{
		printf("Error at opening input file");
		exit(1);
	}
	
    /* Read as much as possible into the `in` vector */
    /* Record the number of bytes actually read */
    numberbytes = fread( ... );
    
    /* Now we can close the input file */
    fclose(f);
    
	// Initialize the random number generator
	srand(0);    
    
    /* Go through all the `in` vector */     
    inpos = 0;   /* the current bit position in the `in` vector */
    while (inpos < numberbytes*8)
    {
        /* Draw a random number x from the random number generator*/
        x = ...;
        
        /* Decide, based on x and p, if the bit shall be toggled or not */
        if ( ... )
        {
            /* If yes, change the bit value (0->1, or 1->0) */
            ...
            
        }
        /* If not, do nothing and leave the bit unchanged */
        
        
        /* Advance inpos position*/
        inpos  = ...;
    }    
    
    /* Open the output file and save all the `in` vector in it, including the CRC-16 value at the end*/
    f = ...;
    fwrite( ... );
    fclose(f);    
    
    
	return 0;
}
