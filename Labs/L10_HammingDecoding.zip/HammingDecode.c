#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)       (((x) & (1U << (i))) != 0)
#define SET_BIT(x,i)        ((x) = (x) | (1U << (i)))
#define CLEAR_BIT(x,i)      ((x) = (x) & ~(1U << (i)))
#define TOGGLE_BIT(x,i)     ((x) = (x) ^ (1U << (i)))
#define WRITE_BIT(x,i,val)  ((val) ? SET_BIT((x),(i)) : CLEAR_BIT((x),(i)))

#define VECREAD_BIT(v,i) (READ_BIT((v[(i)/8]),(i)%8))
#define VECWRITE_BIT(v,i,val) (WRITE_BIT((v[(i)/8]),(i)%8, val))


/* Fire away!
 * Our program needs two arguments: the input file, the output file
 *  */
int main(int argc, char *argv[]) {
	
	/* Small int variables here */
    int i, j, inpos, outpos, parity, numberbytes, sum;
	

    /* Declare two large vectors of `unsigned char`, for input and output bits	*/
    unsigned char in[100000], out[100000];
    
    /* For working with files */
	FILE *f;
    
    /* Open the input file (first argument) and read everything into the `in` vector.
	 * File can be closed afterwards */

	f = ...;
	if(!f)
	{
		printf("eroare la deschidere f1");
		exit(1);
	}
    
    /* Read as much as possible into the `in` vector */
    /* Record the number of bytes actually read */
    numberbytes = fread( ... );
    
    /* Now we can close the input file */
    fclose(f);
    
    /* Go through all the `in` vector */     
    inpos = 0;   /* the current bit position in the `in` vector */
    outpos = 0;  /* the current bit position in the `out` vector */
    while (inpos < numberbytes*8)
    {
        /* Read the next 8 bits of data (the information bits) from the input vector */
        c0 = ...
        c1 = ...
        c2 = ...
        i3 = ...
        c4 = ...
        i5 = ...
        i6 = ...
        i7 = ...
        
        /* Compute the syndrome: z0, z1, z2, and z3*/
        z0 = ...
        z1 = ...
        z2 = ...
        z3 = ...
        
        /* Check for errors and possibly fix them */
        
        
        /* Write the 4 information bits in the output vector */
         
        VECWRITE_BIT(...);
        VECWRITE_BIT(...);
        VECWRITE_BIT(...);
        VECWRITE_BIT(...);
        
        /* Advance inpos and outpos positions*/
        inpos  = ...;
        outpos = ...;
    }
    
	/* Open the output file and save all the `out` vector */
    /* How many bytes should we write? */
	f = ...;
	fwrite( ... );
	fclose(f);

	return 0;
}
