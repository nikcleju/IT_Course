#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)       (((x) & (1U << (i))) != 0)
#define SET_BIT(x,i)        ((x) = (x) | (1U << (i)))
#define CLEAR_BIT(x,i)      ((x) = (x) & ~(1U << (i)))
#define TOGGLE_BIT(x,i)     ((x) = (x) ^ (1U << (i)))
#define WRITE_BIT(x,i,val)  ((val) ? SET_BIT((x),(i)) : CLEAR_BIT((x),(i)))

/* Structure definition for describing a codeword */
typedef struct{

	int len;
	unsigned long code;

}CODE32BIT;

/* Fire away!
 * Our program needs two arguments: the input file, the output file
 *  */
int main(int argc, char *argv[]) {
	
	/* Small int variables here */
    ...
	
	/* A vector of CODE32BIT structures, holding the codeword of each possible byte
	 * This vector will be created by the program, and saved in the output file */
	CODE32BIT codebook[256];
	
	/* A vector of counters and a vector of probabilities */
	int counters[256];
    float prob[256], temp, fract;

	/* A vector for the cumulative probabilities*/
    float cumprob[256];
    
    /* A vector holding the charcaters sorted in descending order of probabilities */
    unsigned char characters[256];

    /* For working with files */
	FILE *f;
    
    /* =========================================================== */
    /* Like in first Lab: compute probabilities of every character */
    
    /* Make all counters start from 0 */
    for (i = 0; i < 256; i++)
        counters[i] = 1;

    /* Initialize characters vector */
    for (i = 0; i < 256; i++)
        characters[i] = i;
	
	/* Open the input file */
	f=fopen(argv[1],"rb");
	if(!f)
	{
		printf("eroare la deschidere f1");
		exit(1);
	}
    
    /* Read every character, increment counters*/
    while(fread(&c, 1, 1, f))
    {
        counters[c]++;
        totalcount++;
    }
        
    /* Compute probabilities */
    for (i = 0; i < 256; i++)
        prob[i] = (float)counters[i] / totalcount;
    
    /* ============================================================ */
        
    /* Shannon coding start here*/

    /* 1. Sort in descending order */
    /* Keep track of final order in the `characters` vector*/
    
    /* Using bubble sort algorithm*/
    for (...)
        for (...)
            if(...)
            {
                /* Swap the probabilities */
                ...
                
                /* Swap the `characters` as well, so we can keep track
                 * which characters correspond to the probabilities  */
                tempchar = characters[j];
                characters[j] = characters[j+1];
                characters[j+1] = tempchar;
            }

    /* 2. Compute the lengths of each codeword */
    for (i = 0; i < 256; i++)
        codebook[characters[i]].len = ...

    /* 3. Compute the cumulative probabilities vector*/
    cumprob[0] = 0;
    for (i = 1; i < 256; i++)
        ...

    /* For debugging, print the cumulative probabilities*/
    printf("Cumulative probabilities:");
    for (i = 0; i < 256; i++)
        printf("%f\n", cumprob[i]);

    /* 4. Compute codewords*/
    for (i = 0; i < 256; i++)
    {
        /* Codeword for `characters[i]` */
        /* Number of bits is `len`*/
        
        /* Start from the cumulative probability value*/
        fract = cumprob[i];
        for (j = 0; j < codebook[characters[i]].len; j++)
        {
            /* Get fractionary bits: multiply by 2, see if larger than 1*/
            fract = ...;
            if (...)
            {
                /* Next bit is 1 */
                SET_BIT(...);
                
                /*Remove 1 from fract, to keep only the fractionary part*/
                ...
            }
            else
            {
                /* Next bit is 0 */
                CLEAR_BIT(...);
            }
        }
    }
    
    /* Print all the codewords like: */
    /* a: 001001 */
    /* b: 01110001 */
    /* ... */
    for (i = 0; i < 256; i++)
    {
        printf("%d (%c): ", i, i);
        for (j=0; ...)
            printf(...);
        printf("\n");
    }
    
	/* Open the output file and save all the `codebook` vector */
	f=fopen(...);
	fwrite(...);
	fclose(f);

	return 0;
}
