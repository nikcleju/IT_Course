#include <stdio.h>
#include <stdlib.h>
#include <math.h>  

// Macro definitions for bit-handling
#define READ_BIT(x,i)   ((x)&(1U<<(i)))
#define CLEAR_BIT(x,i)  ((x)=(x)&~(1U<<(i)))
#define SET_BIT(x,i)    ((x)=(x)|(1U<<(i)))
#define TOGGLE_BIT(x,i) ((x)=(x)^(1U<<(i)))

#define VECREAD_BIT(v,i)       (READ_BIT((v[(i)/8]),(i)%8))
#define VECWRITE_BIT(v,i,val)  (WRITE_BIT((v[(i)/8]),

// Structure to hold the codeword of a byte
typedef struct{
	
	int len;
	unsigned long code;
	
}CODE32BIT;


// Fire away!
int main(int argc, char *argv[]) {
	
	// Define variables here (C-style)
	int i,n=0, bit;
	unsigned char c;
	
	/* Declare a vector of CODE32BIT structures, holding the codeword of each possible byte
	 * The vector data will be read from the code file */
	CODE32BIT v[256];
	
	/* A vector of bytes, to hold all the data from the output file 
	 * We write all the outputs into this vector first, then we write
	 * all the vector to disk in one step */
	unsigned char buff[1000000];
	
	
	
	/* Open the code file (first argument) and read everything into the `codebook` vector.
	 * File can be closed afterwards */
	/*----- TODO: Open code file ------*/
	f = ... ;
	/*---------------------------------*/
	if(!f)
	{
		printf("Eroare la deschiderea fisierului 1");
		exit(1);
	}
	/*----- TODO: Read all the vector `codebook` from the file ------*/
	fread(...);
	/*---------------------------------*/
	
	fclose(f);
	
	
	
	/*----- TODO: Open input file ------*/
	f = ..
	/*------------------------------------*/
	/*----- TODO: Check if file is open, 
	 * display message and exit if it is not ------*/
	if(...)
	{
		...
	}
	
	// Read every byte from the file into variable c, stop when can't read anymore
	while(...)
	{
		// Go through every bit from the codeword of byte c
		for(i=0;i < ... ; ...)
		{
			// This is the next bit from the codeword of byte c
			bit = ...
			
			// Is the bit 1 or 0?
			if( ... )
			{
				// The bit is 1, write a bit of 1 in the output vector `buff` at position n
				VECWRITE_BIT(...);
			}
			else
			{
				// The bit is 1, write a bit of 10 in the output vector `buff` at position n
				VECWRITE_BIT(...);
			}	
			
			// Increment position
			n = ...
		}
	}
	fclose(f);
	
	// Open the output file ...
	f = ...
	// ... and write the full output vector `buff` in the file
	fwrite(..);
	
	// The output file can be closed now
	fclose(f);
	
	// That's all, folks!
	return 0;
}
