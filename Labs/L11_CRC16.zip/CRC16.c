#include <stdio.h>
#include <stdlib.h>
#include <math.h>  


/* Macro definitions for bit-handling */
#define READ_BIT(x,i)       (((x) & (1U << (i))) != 0)
#define SET_BIT(x,i)        ((x) = (x) | (1U << (i)))
#define CLEAR_BIT(x,i)      ((x) = (x) & ~(1U << (i)))
#define TOGGLE_BIT(x,i)     ((x) = (x) ^ (1U << (i)))
#define WRITE_BIT(x,i,val)  ((val) ? SET_BIT((x),(i)) : CLEAR_BIT((x),(i)))

#define VECREAD_BIT(v,i) (READ_BIT((v[(i)/8]),(i)%8))
#define VECWRITE_BIT(v,i,val) (WRITE_BIT((v[(i)/8]),(i)%8, val))


/* Fire away!
 * Our program needs two arguments: the input file, the output file
 *  */
int main(int argc, char *argv[]) {
	
	/* Small int variables here */
    int i, j, inpos, outpos, parity, numberbytes, sum;
	
    /* Declare a large vectors of `unsigned char` for input bits	*/
    unsigned char in[100000], out[100000];
    
    /* For working with files */
	FILE *f;


    /* Declare the polynomial g */
    unsigned char g[] = {1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1};


    /* Open the input file (first argument) and read everything into the `in` vector.
	 * File can be closed afterwards */
	f = ...;
	if(!f)
	{
		printf("eroare la deschidere f1");
		exit(1);
	}
    
    /* Read as much as possible into the `in` vector */
    /* Record the number of bytes actually read */
    numberbytes = fread( ... );
    
    /* Now we can close the input file */
    fclose(f);
    
    /* Go through all the `in` vector */     
    inpos = 0;   /* the current bit position in the `in` vector */
    while (inpos < numberbytes*8)
    {
        /* Check if the current bit is equal to 1*/
        if (...)
        {
            /* If yes, then do a XOR with all the 17 bits in g */
            for (i = 0; i < 17; i++)
            {
                ... 
            }
        }
        
        /* Advance inpos position*/
        inpos  = ...;
    }
    
    /* Decide what to do. Do we have one argument or two?*/
    if (...)
    {
        /* We have two arguments*/
        /* Open the output file and save all the `in` vector in it, including the CRC-16 value at the end*/
        /* How many bytes should we write? */
        f = ...;
        fwrite( ... );
        fclose(f);
    }

    if (...)
    {
        /* We have only one argument*/
        /* Check if all the bits of the CRC-16 value at the end are 0*/

        for (i = 0; i < 16; i++)
        {
            ...
        }
    
        /* Show message */
        if (...)
            printf("File OK\n");
        else
            printf("File corrupted\n");
    }
        

	return 0;
}
